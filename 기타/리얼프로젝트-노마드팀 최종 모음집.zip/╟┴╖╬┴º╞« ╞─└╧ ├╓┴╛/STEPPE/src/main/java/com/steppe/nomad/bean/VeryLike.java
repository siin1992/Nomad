package com.steppe.nomad.bean;

public class VeryLike {
	private int l_num;
	private String l_msetid;
	private String l_mgetid;
	
	public int getL_num() {
		return l_num;
	}
	public void setL_num(int l_num) {
		this.l_num = l_num;
	}
	public String getL_msetid() {
		return l_msetid;
	}
	public void setL_msetid(String l_msetid) {
		this.l_msetid = l_msetid;
	}
	public String getL_mgetid() {
		return l_mgetid;
	}
	public void setL_mgetid(String l_mgetid) {
		this.l_mgetid = l_mgetid;
	}
	
	
}
