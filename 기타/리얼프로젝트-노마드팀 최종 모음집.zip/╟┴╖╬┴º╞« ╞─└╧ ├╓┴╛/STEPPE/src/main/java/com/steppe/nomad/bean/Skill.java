package com.steppe.nomad.bean;

public class Skill {
private int sk_num;
private String m_id;
private String sk_name;
private String sk_grade;
private String sk_career;
private String sk_mid;

public String getSk_mid() {
	return sk_mid;
}
public void setSk_mid(String sk_mid) {
	this.sk_mid = sk_mid;
}
public int getSk_num() {
	return sk_num;
}
public void setSk_num(int sk_num) {
	this.sk_num = sk_num;
}
public String getM_id() {
	return m_id;
}
public void setM_id(String m_id) {
	this.m_id = m_id;
}
public String getSk_name() {
	return sk_name;
}
public void setSk_name(String sk_name) {
	this.sk_name = sk_name;
}
public String getSk_grade() {
	return sk_grade;
}
public void setSk_grade(String sk_grade) {
	this.sk_grade = sk_grade;
}
public String getSk_career() {
	return sk_career;
}
public void setSk_career(String sk_career) {
	this.sk_career = sk_career;
}
}
