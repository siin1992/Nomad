package com.steppe.nomad.bean;

public class Test {
	private int t_num;
	private String t_name;
	private String t_content;
	private String t_no1;
	private String t_no2;
	private String t_no3;
	private String t_no4;
	private int t_answer;
	
	
	
	
	public int getT_num() {
		return t_num;
	}
	public void setT_num(int t_num) {
		this.t_num = t_num;
	}
	public String getT_name() {
		return t_name;
	}
	public void setT_name(String t_name) {
		this.t_name = t_name;
	}
	public String getT_content() {
		return t_content;
	}
	public void setT_content(String t_content) {
		this.t_content = t_content;
	}
	public String getT_no1() {
		return t_no1;
	}
	public void setT_no1(String t_no1) {
		this.t_no1 = t_no1;
	}
	public String getT_no2() {
		return t_no2;
	}
	public void setT_no2(String t_no2) {
		this.t_no2 = t_no2;
	}
	public String getT_no3() {
		return t_no3;
	}
	public void setT_no3(String t_no3) {
		this.t_no3 = t_no3;
	}
	public String getT_no4() {
		return t_no4;
	}
	public void setT_no4(String t_no4) {
		this.t_no4 = t_no4;
	}
	public int getT_answer() {
		return t_answer;
	}
	public void setT_answer(int t_answer) {
		this.t_answer = t_answer;
	}
	
	
}
