package com.steppe.nomad.bean;

public class Chat {
	private int c_id;
	private int c_pnum;
	private String c_mid;
	private String c_content;
	private String c_date;
	
	public int getC_id() {
		return c_id;
	}
	public void setC_id(int c_id) {
		this.c_id = c_id;
	}
	public int getC_pnum() {
		return c_pnum;
	}
	public void setC_pnum(int c_pnum) {
		this.c_pnum = c_pnum;
	}
	public String getC_mid() {
		return c_mid;
	}
	public void setC_mid(String c_mid) {
		this.c_mid = c_mid;
	}
	public String getC_content() {
		return c_content;
	}
	public void setC_content(String c_content) {
		this.c_content = c_content;
	}
	public String getC_date() {
		return c_date;
	}
	public void setC_date(String c_date) {
		this.c_date = c_date;
	}
}
