package com.steppe.nomad.bean;

public class Report {
	private String r_mid;
	private int r_num;
	private String r_kind;
	private String r_content;
	private String r_url;
	public String getR_mid() {
		return r_mid;
	}
	public void setR_mid(String r_mid) {
		this.r_mid = r_mid;
	}
	public int getR_num() {
		return r_num;
	}
	public void setR_num(int r_num) {
		this.r_num = r_num;
	}
	public String getR_kind() {
		return r_kind;
	}
	public void setR_kind(String r_kind) {
		this.r_kind = r_kind;
	}
	public String getR_content() {
		return r_content;
	}
	public void setR_content(String r_content) {
		this.r_content = r_content;
	}
	public String getR_url() {
		return r_url;
	}
	public void setR_url(String r_url) {
		this.r_url = r_url;
	}
	
	
	
}
