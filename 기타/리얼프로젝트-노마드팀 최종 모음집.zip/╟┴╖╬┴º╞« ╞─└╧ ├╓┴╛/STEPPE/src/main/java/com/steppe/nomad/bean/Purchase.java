package com.steppe.nomad.bean;

public class Purchase {
	private int pu_num;
	private double pu_money;
	private String pu_mid;
	private int pu_pnum;
	
	public int getPu_num() {
		return pu_num;
	}
	public void setPu_num(int pu_num) {
		this.pu_num = pu_num;
	}
	public double getPu_money() {
		return pu_money;
	}
	public void setPu_money(double pu_money) {
		this.pu_money = pu_money;
	}
	public String getPu_mid() {
		return pu_mid;
	}
	public void setPu_mid(String pu_mid) {
		this.pu_mid = pu_mid;
	}
	public int getPu_pnum() {
		return pu_pnum;
	}
	public void setPu_pnum(int pu_pnum) {
		this.pu_pnum = pu_pnum;
	}
	
	
}
