package com.steppe.nomad.bean;

public class Project_bookmark {
	private int pb_num;
	private int pb_pnum;
	private String pb_id;
	private String pb_mid;
	private int pb_flag;
	
	public int getPb_num() {
		return pb_num;
	}
	public void setPb_num(int pb_num) {
		this.pb_num = pb_num;
	}
	public int getPb_pnum() {
		return pb_pnum;
	}
	public void setPb_pnum(int pb_pnum) {
		this.pb_pnum = pb_pnum;
	}

	public String getPb_id() {
		return pb_id;
	}
	public void setPb_id(String pb_id) {
		this.pb_id = pb_id;
	}

	public String getPb_mid() {
		return pb_mid;
	}
	public void setPb_mid(String pb_mid) {
		this.pb_mid = pb_mid;
	}
	public int getPb_flag() {
		return pb_flag;
	}
	public void setPb_flag(int pb_flag) {
		this.pb_flag = pb_flag;
	}

	
	
}
