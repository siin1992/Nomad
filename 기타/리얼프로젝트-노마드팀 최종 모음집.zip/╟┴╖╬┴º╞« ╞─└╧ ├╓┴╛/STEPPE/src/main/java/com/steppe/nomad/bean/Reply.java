package com.steppe.nomad.bean;

public class Reply {
	private String r_mid;
	private int r_num;
	private int r_pnum;
	private String r_content;
	private String r_date;
	
	
	public String getR_mid() {
		return r_mid;
	}
	public void setR_mid(String r_mid) {
		this.r_mid = r_mid;
	}
	public int getR_num() {
		return r_num;
	}
	public void setR_num(int r_num) {
		this.r_num = r_num;
	}
	public int getR_pnum() {
		return r_pnum;
	}
	public void setR_pnum(int r_pnum) {
		this.r_pnum = r_pnum;
	}
	public String getR_content() {
		return r_content;
	}
	public void setR_content(String r_content) {
		this.r_content = r_content;
	}
	public String getR_date() {
		return r_date;
	}
	public void setR_date(String r_date) {
		this.r_date = r_date;
	}
}
