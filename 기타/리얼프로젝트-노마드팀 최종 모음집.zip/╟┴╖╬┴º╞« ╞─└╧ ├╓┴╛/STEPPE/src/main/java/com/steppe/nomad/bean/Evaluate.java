package com.steppe.nomad.bean;

public class Evaluate {
	int e_num; 
	int e_score;      
	String e_content;
	String e_mid; 
	int e_pnum;
	
	public int getE_num() {
		return e_num;
	}
	public void setE_num(int e_num) {
		this.e_num = e_num;
	}
	public int getE_score() {
		return e_score;
	}
	public void setE_score(int e_score) {
		this.e_score = e_score;
	}
	public String getE_content() {
		return e_content;
	}
	public void setE_content(String e_content) {
		this.e_content = e_content;
	}
	public String getE_mid() {
		return e_mid;
	}
	public void setE_mid(String e_mid) {
		this.e_mid = e_mid;
	}
	public int getE_pnum() {
		return e_pnum;
	}
	public void setE_pnum(int e_pnum) {
		this.e_pnum = e_pnum;
	}
	
}
