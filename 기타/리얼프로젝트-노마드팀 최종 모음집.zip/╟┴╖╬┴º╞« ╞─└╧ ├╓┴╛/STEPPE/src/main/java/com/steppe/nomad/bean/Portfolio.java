package com.steppe.nomad.bean;

public class Portfolio {

private int pf_num;
private String pf_mid;
private String pf_title;
private String pf_term;
private String pf_contribute;
private String pf_content;
private String pt_sysname;

public String getPt_sysname() {
	return pt_sysname;
}
public void setPt_sysname(String pt_sysname) {
	this.pt_sysname = pt_sysname;
}
public int getPf_num() {
	return pf_num;
}
public void setPf_num(int pf_num) {
	this.pf_num = pf_num;
}

public String getPf_mid() {
	return pf_mid;
}
public void setPf_mid(String pf_mid) {
	this.pf_mid = pf_mid;

}
public String getPf_title() {
	return pf_title;
}
public void setPf_title(String pf_title) {
	this.pf_title = pf_title;
}
public String getPf_term() {
	return pf_term;
}
public void setPf_term(String pf_term) {
	this.pf_term = pf_term;
}
public String getPf_contribute() {
	return pf_contribute;
}
public void setPf_contribute(String pf_contribute) {
	this.pf_contribute = pf_contribute;
}
public String getPf_content() {
	return pf_content;
}
public void setPf_content(String pf_content) {
	this.pf_content = pf_content;
}

}
