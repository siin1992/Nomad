package com.steppe.nomad.bean;

public class Catagory {

	private int pc1_id;
	private String pc1_name;
	private int pc2_id;
	private String pc2_name;
	private int pc2_pc1id;
	
	
	public int getPc1_id() {
		return pc1_id;
	}
	public void setPc1_id(int pc1_id) {
		this.pc1_id = pc1_id;
	}
	public String getPc1_name() {
		return pc1_name;
	}
	public void setPc1_name(String pc1_name) {
		this.pc1_name = pc1_name;
	}
	public int getPc2_id() {
		return pc2_id;
	}
	public void setPc2_id(int pc2_id) {
		this.pc2_id = pc2_id;
	}
	public String getPc2_name() {
		return pc2_name;
	}
	public void setPc2_name(String pc2_name) {
		this.pc2_name = pc2_name;
	}
	public int getPc2_pc1id() {
		return pc2_pc1id;
	}
	public void setPc2_pc1id(int pc2_pc1id) {
		this.pc2_pc1id = pc2_pc1id;
	}
	
	
	
}
