package com.steppe.nomad.bean;

public class Required_Skill {
	private int rs_id;
	private String rs_plnum;
	
	
	public int getRs_id() {
		return rs_id;
	}
	public void setRs_id(int rs_id) {
		this.rs_id = rs_id;
	}
	public String getRs_plnum() {
		return rs_plnum;
	}
	public void setRs_plnum(String rs_plnum) {
		this.rs_plnum = rs_plnum;
	}
	

}
