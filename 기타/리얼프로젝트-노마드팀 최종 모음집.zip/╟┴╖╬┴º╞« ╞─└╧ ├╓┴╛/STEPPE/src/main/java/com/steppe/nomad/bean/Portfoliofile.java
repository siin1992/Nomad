package com.steppe.nomad.bean;

public class Portfoliofile {
	private int pt_num;
	private int pt_pfnum;
	private String pt_oriname;
	private String pt_sysname;
	public String getPt_oriname() {
		return pt_oriname;
	}
	public void setPt_oriname(String pt_oriname) {
		this.pt_oriname = pt_oriname;
	}
	public int getPt_num() {
		return pt_num;
	}
	public void setPt_num(int pt_num) {
		this.pt_num = pt_num;
	}
	public int getPt_pfnum() {
		return pt_pfnum;
	}
	public void setPt_pfnum(int pt_pfnum) {
		this.pt_pfnum = pt_pfnum;
	}
	public String getPt_sysname() {
		return pt_sysname;
	}
	public void setPt_sysname(String pt_sysname) {
		this.pt_sysname = pt_sysname;
	}

}
