package com.steppe.nomad.bean;

public class Purchase_detail {
	private int pd_num;
	private int pd_punum;
	private String pd_mid;
	private double pd_money;
	private String pd_catagory;
	private String pd_catagory2;
	
	public Purchase_detail(){
		
	}
	
	public int getPd_num() {
		return pd_num;
	}
	public void setPd_num(int pd_num) {
		this.pd_num = pd_num;
	}
	public int getPd_punum() {
		return pd_punum;
	}
	public void setPd_punum(int pd_punum) {
		this.pd_punum = pd_punum;
	}
	public String getPd_mid() {
		return pd_mid;
	}
	public void setPd_mid(String pd_mid) {
		this.pd_mid = pd_mid;
	}
	public double getPd_money() {
		return pd_money;
	}
	public void setPd_money(double pd_money) {
		this.pd_money = pd_money;
	}
	public String getPd_catagory() {
		return pd_catagory;
	}
	public void setPd_catagory(String pd_catagory) {
		this.pd_catagory = pd_catagory;
	}

	public String getPd_catagory2() {
		return pd_catagory2;
	}
	public void setPd_catagory2(String pd_catagory2) {
		this.pd_catagory2 = pd_catagory2;
	}
	

	
}
