package com.steppe.nomad.bean;

public class Career {
private int ca_num;
private String m_id;
private String ca_term;
private String ca_company;
private String ca_rank;
public int getCa_num() {
	return ca_num;
}
public void setCa_num(int ca_num) {
	this.ca_num = ca_num;
}
public String getM_id() {
	return m_id;
}
public void setM_id(String m_id) {
	this.m_id = m_id;
}
public String getCa_term() {
	return ca_term;
}
public void setCa_term(String ca_term) {
	this.ca_term = ca_term;
}
public String getCa_company() {
	return ca_company;
}
public void setCa_company(String ca_company) {
	this.ca_company = ca_company;
}
public String getCa_rank() {
	return ca_rank;
}
public void setCa_rank(String ca_rank) {
	this.ca_rank = ca_rank;
}


}
