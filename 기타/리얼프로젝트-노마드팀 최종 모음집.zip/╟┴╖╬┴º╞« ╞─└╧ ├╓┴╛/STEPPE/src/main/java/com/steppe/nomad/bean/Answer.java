package com.steppe.nomad.bean;

public class Answer {
	private int a_num;
	private int a_insertnum;
	private int a_check;
	private int a_tnum;
	private String a_mid;
	private String a_tname;
	public int getA_num() {
		return a_num;
	}
	public void setA_num(int a_num) {
		this.a_num = a_num;
	}
	public int getA_insertnum() {
		return a_insertnum;
	}
	public void setA_insertnum(int a_insertnum) {
		this.a_insertnum = a_insertnum;
	}
	public int getA_check() {
		return a_check;
	}
	public void setA_check(int a_check) {
		this.a_check = a_check;
	}
	public int getA_tnum() {
		return a_tnum;
	}
	public void setA_tnum(int a_tnum) {
		this.a_tnum = a_tnum;
	}
	public String getA_mid() {
		return a_mid;
	}
	public void setA_mid(String a_mid) {
		this.a_mid = a_mid;
	}
	public String getA_tname() {
		return a_tname;
	}
	public void setA_tname(String a_tname) {
		this.a_tname = a_tname;
	}
	
	
}