package com.steppe.nomad.bean;

public class Result {
	private int rs_num;
	private String rs_mid;
	private String rs_tname;
	private int rs_pc;
	
	public int getRs_num() {
		return rs_num;
	}
	public void setRs_num(int rs_num) {
		this.rs_num = rs_num;
	}
	public String getRs_mid() {
		return rs_mid;
	}
	public void setRs_mid(String rs_mid) {
		this.rs_mid = rs_mid;
	}
	public String getRs_tname() {
		return rs_tname;
	}
	public void setRs_tname(String rs_tname) {
		this.rs_tname = rs_tname;
	}
	public int getRs_pc() {
		return rs_pc;
	}
	public void setRs_pc(int rs_pc) {
		this.rs_pc = rs_pc;
	}
	

	
	
}
